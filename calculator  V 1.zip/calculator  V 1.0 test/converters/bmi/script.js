document.addEventListener('DOMContentLoaded', () => {
    const weightInput = document.getElementById('weight');
    const heightInput = document.getElementById('height');
    const resultValue = document.getElementById('result-value');
    const resultCategory = document.getElementById('result-category');

    function calculateBMI() {
        const weight = parseFloat(weightInput.value);
        const height = parseFloat(heightInput.value);

        if (isNaN(weight) || isNaN(height) || height <= 0 || weight <= 0) {
            resultValue.textContent = '-';
            resultCategory.textContent = '';
            return;
        }

        const heightInMeters = height / 100;
        const bmi = weight / (heightInMeters * heightInMeters);
        
        resultValue.textContent = bmi.toFixed(2);

        if (bmi < 18.5) {
            resultCategory.textContent = 'Underweight';
        } else if (bmi >= 18.5 && bmi < 24.9) {
            resultCategory.textContent = 'Normal weight';
        } else if (bmi >= 25 && bmi < 29.9) {
            resultCategory.textContent = 'Overweight';
        } else {
            resultCategory.textContent = 'Obesity';
        }
    }

    weightInput.addEventListener('input', calculateBMI);
    heightInput.addEventListener('input', calculateBMI);
});