document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    // Conversion factors to a base unit (Seconds)
    const toSeconds = {
        second: 1,
        minute: 60,
        hour: 3600,
        day: 86400,
        week: 604800,
        month: 2592000, // Approx 30 days
        year: 31536000 // Approx 365 days
    };

    function convertTime() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        const valueInSeconds = value * toSeconds[from];
        const result = valueInSeconds / toSeconds[to];

        resultValue.textContent = result.toLocaleString();
    }

    fromUnit.addEventListener('change', convertTime);
    toUnit.addEventListener('change', convertTime);
    fromValue.addEventListener('input', convertTime);
});