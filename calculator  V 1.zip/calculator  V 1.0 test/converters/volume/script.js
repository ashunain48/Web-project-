document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    // Conversion factors to a base unit (Liters)
    const toLiters = {
        liter: 1,
        milliliter: 0.001,
        gallon_us: 3.78541,
        quart_us: 0.946353,
        pint_us: 0.473176,
        cup_us: 0.236588,
        cubic_meter: 1000
    };

    function convertVolume() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        const valueInLiters = value * toLiters[from];
        const result = valueInLiters / toLiters[to];

        resultValue.textContent = result.toLocaleString();
    }

    fromUnit.addEventListener('change', convertVolume);
    toUnit.addEventListener('change', convertVolume);
    fromValue.addEventListener('input', convertVolume);
});