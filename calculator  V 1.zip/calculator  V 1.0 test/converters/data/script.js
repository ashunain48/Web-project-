document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    // Conversion factors to a base unit (bytes)
    const toBytes = {
        byte: 1,
        kilobyte: 1024,
        megabyte: 1024 ** 2,
        gigabyte: 1024 ** 3,
        terabyte: 1024 ** 4
    };

    function convertData() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        const valueInBytes = value * toBytes[from];
        const result = valueInBytes / toBytes[to];

        resultValue.textContent = result.toLocaleString();
    }

    fromUnit.addEventListener('change', convertData);
    toUnit.addEventListener('change', convertData);
    fromValue.addEventListener('input', convertData);
});