document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    // Conversion factors to a base unit (Meters per Second)
    const toMps = {
        mps: 1,
        kph: 0.277778,
        mph: 0.44704,
        knot: 0.514444
    };

    function convertSpeed() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        const valueInMps = value * toMps[from];
        const result = valueInMps / toMps[to];

        resultValue.textContent = result.toLocaleString();
    }

    fromUnit.addEventListener('change', convertSpeed);
    toUnit.addEventListener('change', convertSpeed);
    fromValue.addEventListener('input', convertSpeed);
});