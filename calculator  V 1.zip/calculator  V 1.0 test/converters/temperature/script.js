document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    function convertTemperature() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        let celsius;
        // Step 1: Convert input to Celsius
        switch (from) {
            case 'celsius':
                celsius = value;
                break;
            case 'fahrenheit':
                celsius = (value - 32) * 5 / 9;
                break;
            case 'kelvin':
                celsius = value - 273.15;
                break;
        }

        let result;
        // Step 2: Convert from Celsius to target unit
        switch (to) {
            case 'celsius':
                result = celsius;
                break;
            case 'fahrenheit':
                result = (celsius * 9 / 5) + 32;
                break;
            case 'kelvin':
                result = celsius + 273.15;
                break;
        }

        resultValue.textContent = result.toFixed(2);
    }

    fromUnit.addEventListener('change', convertTemperature);
    toUnit.addEventListener('change', convertTemperature);
    fromValue.addEventListener('input', convertTemperature);
});