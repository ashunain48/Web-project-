document.addEventListener('DOMContentLoaded', () => {
    const fromDateInput = document.getElementById('from-date');
    const toDateInput = document.getElementById('to-date');
    const resultValue = document.getElementById('result-value');
    const totalDaysValue = document.getElementById('total-days');

    // Set default 'to' date to today
    const today = new Date();
    toDateInput.value = today.toISOString().split('T')[0];

    function calculateDateDifference() {
        const fromDate = new Date(fromDateInput.value);
        const toDate = new Date(toDateInput.value);

        if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime()) || fromDate > toDate) {
            resultValue.textContent = '-';
            totalDaysValue.textContent = '-';
            return;
        }

        // Calculate total days difference
        const diffTime = Math.abs(toDate - fromDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        totalDaysValue.textContent = diffDays.toLocaleString();

        // Calculate difference in years, months, days
        let years = toDate.getFullYear() - fromDate.getFullYear();
        let months = toDate.getMonth() - fromDate.getMonth();
        let days = toDate.getDate() - fromDate.getDate();

        if (days < 0) {
            months--;
            // Get the last day of the previous month
            days += new Date(toDate.getFullYear(), toDate.getMonth(), 0).getDate();
        }

        if (months < 0) {
            years--;
            months += 12;
        }
        
        resultValue.textContent = `${years} years, ${months} months, ${days} days`;
    }

    fromDateInput.addEventListener('change', calculateDateDifference);
    toDateInput.addEventListener('change', calculateDateDifference);
    
    // Initial calculation on load
    calculateDateDifference();
});