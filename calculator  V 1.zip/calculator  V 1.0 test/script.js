document.addEventListener('DOMContentLoaded', () => {
    // --- Screen Switching Logic ---
    const screens = document.querySelectorAll('.screen');
    const navIcons = document.querySelectorAll('.nav-icons i');
    function switchScreen(targetId) {
        screens.forEach(screen => screen.classList.remove('active'));
        navIcons.forEach(icon => icon.classList.remove('active-nav'));
        const targetScreen = document.getElementById(targetId);
        const targetIcon = document.querySelector(`[id="show-${targetId.split('-')[0]}"]`);
        if (targetScreen) targetScreen.classList.add('active');
        if (targetIcon) targetIcon.classList.add('active-nav');
    }
    navIcons.forEach(icon => {
        icon.addEventListener('click', (e) => {
            const screenName = e.target.id.split('-')[1];
            switchScreen(`${screenName}-screen`);
            history.pushState("", document.title, window.location.pathname + window.location.search);
        });
    });
    if (window.location.hash) {
        const hash = window.location.hash.substring(1);
        if (document.getElementById(hash)) switchScreen(hash);
    } else {
        switchScreen('calculator-screen');
    }

    // --- ACCURATE SCIENTIFIC CALCULATOR ENGINE ---

    const calculatorScreen = document.getElementById('calculator-screen');
    const expressionDisplay = document.getElementById('expression');
    const resultDisplay = document.getElementById('result');
    const allButtons = document.querySelectorAll('.buttons-container .btn');
    const secondToggleButton = document.getElementById('toggle-2nd');
    const degToggleButton = document.getElementById('toggle-deg');
    const funcButtonsWith2nd = document.querySelectorAll('[data-2nd]');
    const historyPanel = document.getElementById('history-panel');
    const historyList = document.getElementById('history-list');
    const historyBtn = document.getElementById('history-btn');
    const closeHistoryBtn = document.getElementById('close-history-btn');

    let expression = '0';
    let isDeg = true;
    let is2nd = false;
    let isResultShown = false;
    let calculationHistory = [];

    const precedence = { '+': 1, '-': 1, '*': 2, '÷': 2, '%': 2, '^': 3, 'nrt': 3 };
    const functions = ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'lg', 'ln', 'sqrt', 'cbrt', '!'];
    const constants = { 'pi': Math.PI, 'e': Math.E };

    function factorial(n) {
        if (n < 0 || n % 1 !== 0) return NaN;
        if (n === 0 || n === 1) return 1;
        let result = 1;
        for (let i = 2; i <= n; i++) result *= i;
        return result;
    }

    function tokenize(expr) {
        const regex = /(\d+\.?\d*)|([+\-÷*^%()!])|(pi|e)|(sin|cos|tan|asin|acos|atan|lg|ln|sqrt|cbrt|nrt)/g;
        return expr.replace(/×/g, '*').match(regex) || [];
    }

    function infixToPostfix(tokens) {
        const outputQueue = [], operatorStack = [];
        const tokenPrecedence = t => precedence[t] || 0;
        tokens.forEach(token => {
            if (!isNaN(parseFloat(token))) outputQueue.push(parseFloat(token));
            else if (constants[token]) outputQueue.push(constants[token]);
            else if (functions.includes(token)) operatorStack.push(token);
            else if (token === '(') operatorStack.push(token);
            else if (token === ')') {
                while (operatorStack.length && operatorStack[operatorStack.length - 1] !== '(') outputQueue.push(operatorStack.pop());
                operatorStack.pop();
                if (functions.includes(operatorStack[operatorStack.length - 1])) outputQueue.push(operatorStack.pop());
            } else {
                while (operatorStack.length && operatorStack[operatorStack.length - 1] !== '(' && tokenPrecedence(operatorStack[operatorStack.length - 1]) >= tokenPrecedence(token)) {
                    outputQueue.push(operatorStack.pop());
                }
                operatorStack.push(token);
            }
        });
        while (operatorStack.length) outputQueue.push(operatorStack.pop());
        return outputQueue;
    }

    function evaluatePostfix(postfix) {
        const stack = [];
        postfix.forEach(token => {
            if (typeof token === 'number') stack.push(token);
            else if (functions.includes(token)) {
                const op = stack.pop();
                if (op === undefined) throw new Error("Invalid");
                switch (token) {
                    case 'sin': stack.push(Math.sin(isDeg ? op * Math.PI / 180 : op)); break;
                    case 'cos': stack.push(Math.cos(isDeg ? op * Math.PI / 180 : op)); break;
                    case 'tan': stack.push(Math.tan(isDeg ? op * Math.PI / 180 : op)); break;
                    case 'asin': stack.push(isDeg ? Math.asin(op) * 180 / Math.PI : Math.asin(op)); break;
                    case 'acos': stack.push(isDeg ? Math.acos(op) * 180 / Math.PI : Math.acos(op)); break;
                    case 'atan': stack.push(isDeg ? Math.atan(op) * 180 / Math.PI : Math.atan(op)); break;
                    case 'lg': stack.push(Math.log10(op)); break;
                    case 'ln': stack.push(Math.log(op)); break;
                    case 'sqrt': stack.push(Math.sqrt(op)); break;
                    case 'cbrt': stack.push(Math.cbrt(op)); break;
                    case '!': stack.push(factorial(op)); break;
                }
            } else {
                const b = stack.pop(), a = stack.pop();
                if (a === undefined || b === undefined) throw new Error("Invalid");
                switch (token) {
                    case '+': stack.push(a + b); break;
                    case '-': stack.push(a - b); break;
                    case '*': stack.push(a * b); break;
                    case '÷': stack.push(a / b); break;
                    case '^': stack.push(Math.pow(a, b)); break;
                    case '%': stack.push(a % b); break;
                    case 'nrt': stack.push(Math.pow(b, 1 / a)); break;
                }
            }
        });
        return stack.pop();
    }
    
    function evaluateLive() {
         try {
            if (isResultShown || /[%÷×\-+^]$/.test(expression)) {
                resultDisplay.value = '';
                return;
            }
            let processedExpr = expression.replace(/(\d|\))(\(|pi|e|sqrt|cbrt|sin|cos|tan|lg|ln)/g, '$1*$2').replace(/\)(\d)/g, ')*$1');
            const tokens = tokenize(processedExpr);
            const postfix = infixToPostfix(tokens);
            const result = evaluatePostfix(postfix);
            if (result !== null && result.toString() !== expression) {
                resultDisplay.value = result.toLocaleString('en-US', {maximumFractionDigits: 9});
            } else {
                resultDisplay.value = '';
            }
        } catch (error) {
            resultDisplay.value = '';
        }
    }

    function updateDisplay() {
        expressionDisplay.value = expression.replace(/\*/g, '×').replace(/nrt/g, 'yroot') || '0';
        evaluateLive();
    }

    function addToHistory() {
        evaluateLive(); // Ensure result is calculated
        if (resultDisplay.value) {
            calculationHistory.unshift({
                expr: expressionDisplay.value,
                res: resultDisplay.value
            });
        }
    }

    function renderHistory() {
        if (calculationHistory.length === 0) {
            historyList.innerHTML = '<p class="no-history">No history yet.</p>';
        } else {
            historyList.innerHTML = calculationHistory.map(item => `
                <div class="history-item">
                    <div class="expr">${item.expr}</div>
                    <div class="res">= ${item.res}</div>
                </div>`).join('');
        }
    }
    
    function toggle2nd() {
        is2nd = !is2nd;
        secondToggleButton.classList.toggle('active', is2nd);
        funcButtonsWith2nd.forEach(btn => {
            const originalValue = btn.dataset.value;
            const secondValue = btn.dataset['2nd'];
            btn.innerHTML = is2nd ? secondValue.replace('^', '<sup>x</sup>') : originalValue.replace('^', '<sup>y</sup>');
        });
    }

    allButtons.forEach(button => {
        button.addEventListener('click', () => {
            let value = button.dataset.value;
            if (is2nd && button.dataset['2nd']) value = button.dataset['2nd'];
            if (isResultShown && !['+', '-', '*', '÷', '^', '%', 'nrt'].includes(value)) {
                expression = ''; isResultShown = false;
            }
            if (expression === '0' && !isNaN(value) && value !== '.') expression = '';

            switch (value) {
                case 'C': expression = '0'; isResultShown = false; break;
                case 'DEL': expression = expression.length > 1 ? expression.slice(0, -1) : '0'; isResultShown = false; break;
                case '=': addToHistory(); if (resultDisplay.value) { expression = resultDisplay.value.replace(/,/g, ''); isResultShown = true; } break;
                case 'toggle-sci': calculatorScreen.classList.toggle('scientific-mode-active'); break;
                case '2nd': toggle2nd(); break;
                case 'deg': isDeg = !isDeg; degToggleButton.textContent = isDeg ? 'deg' : 'rad'; break;
                case '1/x': expression += '^(-1)'; break;
                case '10^': expression += '10^('; break;
                case 'e^': expression += 'e^('; break;
                default: expression += value;
            }
            if (!['2nd', 'toggle-sci'].includes(value)) updateDisplay();
        });
    });

    historyBtn.addEventListener('click', () => {
        renderHistory();
        historyPanel.classList.add('show');
    });
    
    closeHistoryBtn.addEventListener('click', () => {
        historyPanel.classList.remove('show');
    });
    
    updateDisplay();
});