document.addEventListener('DOMContentLoaded', () => {
    const powerInput = document.getElementById('power');
    const hoursInput = document.getElementById('hours');
    const costInput = document.getElementById('cost');
    const dailyCostEl = document.getElementById('daily-cost');
    const monthlyCostEl = document.getElementById('monthly-cost');
    const yearlyCostEl = document.getElementById('yearly-cost');
    const yearlyKwhEl = document.getElementById('yearly-kwh');

    function calculateElectricityCost() {
        const power = parseFloat(powerInput.value);
        const hours = parseFloat(hoursInput.value);
        const cost = parseFloat(costInput.value);

        if (isNaN(power) || isNaN(hours) || isNaN(cost) || power <= 0 || hours <= 0 || cost < 0) {
            dailyCostEl.textContent = '-';
            monthlyCostEl.textContent = '-';
            yearlyCostEl.textContent = '-';
            yearlyKwhEl.textContent = '-';
            return;
        }

        const dailyKwh = (power * hours) / 1000;
        const dailyCost = dailyKwh * cost;
        const monthlyCost = dailyCost * 30;
        const yearlyCost = dailyCost * 365;
        const yearlyKwh = dailyKwh * 365;

        // THE FIX: Changed currency from 'USD' to 'INR'
        const currencyOptions = { style: 'currency', currency: 'INR', minimumFractionDigits: 2 };

        dailyCostEl.textContent = dailyCost.toLocaleString('en-IN', currencyOptions);
        monthlyCostEl.textContent = monthlyCost.toLocaleString('en-IN', currencyOptions);
        yearlyCostEl.textContent = yearlyCost.toLocaleString('en-IN', currencyOptions);
        yearlyKwhEl.textContent = `${yearlyKwh.toFixed(2)} kWh`;
    }

    powerInput.addEventListener('input', calculateElectricityCost);
    hoursInput.addEventListener('input', calculateElectricityCost);
    costInput.addEventListener('input', calculateElectricityCost);
});