document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    // Exchange rates relative to a base currency (USD)
    // In a real app, you would fetch this from an API.
    const rates = {
        USD: 1,
        EUR: 0.92,
        JPY: 157.5,
        GBP: 0.78,
        INR: 83.4
    };

    function convertCurrency() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        const valueInUsd = value / rates[from];
        const result = valueInUsd * rates[to];

        resultValue.textContent = result.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    fromUnit.addEventListener('change', convertCurrency);
    toUnit.addEventListener('change', convertCurrency);
    fromValue.addEventListener('input', convertCurrency);
});