document.addEventListener('DOMContentLoaded', () => {
    const costPriceInput = document.getElementById('cost-price');
    const sellingPriceInput = document.getElementById('selling-price');
    const resultTitle = document.getElementById('result-title');
    const amountResult = document.getElementById('profit-loss-amount');
    const percentResult = document.getElementById('profit-loss-percent');

    function calculateProfitLoss() {
        const cp = parseFloat(costPriceInput.value);
        const sp = parseFloat(sellingPriceInput.value);

        if (isNaN(cp) || isNaN(sp)) {
            resultTitle.textContent = 'Result';
            amountResult.textContent = '-';
            percentResult.textContent = '-';
            return;
        }

        const difference = sp - cp;
        let percentage = 0;

        if (cp > 0) {
            percentage = (difference / cp) * 100;
        }

        if (difference > 0) {
            resultTitle.textContent = 'Profit';
            amountResult.textContent = difference.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            percentResult.textContent = `${percentage.toFixed(2)}%`;
        } else if (difference < 0) {
            resultTitle.textContent = 'Loss';
            amountResult.textContent = Math.abs(difference).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            percentResult.textContent = `${Math.abs(percentage).toFixed(2)}%`;
        } else {
            resultTitle.textContent = 'Result';
            amountResult.textContent = 'No Profit, No Loss';
            percentResult.textContent = '0.00%';
        }
    }

    costPriceInput.addEventListener('input', calculateProfitLoss);
    sellingPriceInput.addEventListener('input', calculateProfitLoss);
});