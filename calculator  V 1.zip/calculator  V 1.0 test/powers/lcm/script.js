document.addEventListener('DOMContentLoaded', () => {
    const numberInput = document.getElementById('number-input');
    const resultValue = document.getElementById('result-value');

    // Helper function for HCF (GCD), needed to calculate LCM
    const hcf = (a, b) => {
        while (b) {
            [a, b] = [b, a % b];
        }
        return a;
    };

    // Function to calculate LCM of two numbers
    const lcm = (a, b) => {
        return Math.abs(a * b) / hcf(a, b);
    };

    function calculateLCM() {
        const inputValue = numberInput.value.trim();
        if (!inputValue) {
            resultValue.textContent = '-';
            return;
        }

        // Parse numbers from input string
        const numbers = inputValue
            .split(/\s+/)
            .map(Number)
            .filter(n => !isNaN(n) && n > 0 && Number.isInteger(n));

        if (numbers.length < 2) {
            resultValue.textContent = 'Enter at least two numbers';
            return;
        }
        
        // Calculate LCM of all numbers by reducing the array
        const result = numbers.reduce((acc, current) => lcm(acc, current));

        resultValue.textContent = result.toLocaleString();
    }

    numberInput.addEventListener('input', calculateLCM);
});