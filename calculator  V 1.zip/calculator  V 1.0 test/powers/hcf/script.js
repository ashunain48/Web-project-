document.addEventListener('DOMContentLoaded', () => {
    const numberInput = document.getElementById('number-input');
    const resultValue = document.getElementById('result-value');

    // Function to calculate HCF (GCD) of two numbers using Euclidean algorithm
    const hcf = (a, b) => {
        while (b) {
            [a, b] = [b, a % b];
        }
        return a;
    };

    function calculateHCF() {
        const inputValue = numberInput.value.trim();
        if (!inputValue) {
            resultValue.textContent = '-';
            return;
        }

        // Parse numbers from input string
        const numbers = inputValue
            .split(/\s+/)
            .map(Number)
            .filter(n => !isNaN(n) && n > 0 && Number.isInteger(n));

        if (numbers.length < 2) {
            resultValue.textContent = 'Enter at least two numbers';
            return;
        }

        // Calculate HCF of all numbers by reducing the array
        const result = numbers.reduce((acc, current) => hcf(acc, current));
        
        resultValue.textContent = result.toLocaleString();
    }

    numberInput.addEventListener('input', calculateHCF);
});